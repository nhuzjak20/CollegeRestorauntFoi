﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeRestraunt.classes
{
    public class StudentClass
    {
        public string ID, JMBAG, ImeIprezime;
        public StudentClass(string id, string jmbag, string imeiprezime) { ID = id; JMBAG = jmbag; ImeIprezime = imeiprezime; } 
    }
}
